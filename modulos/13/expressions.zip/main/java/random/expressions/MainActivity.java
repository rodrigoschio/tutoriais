package random.expressions;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.graphics.Color;
import android.widget.RelativeLayout.LayoutParams;
import android.view.Gravity;

public class MainActivity extends Activity{
	WebView expressionView;
	@Override protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LinearLayout linearLayout=new LinearLayout(this);
		linearLayout.setOrientation(linearLayout.VERTICAL);
		
		expressionView=new WebView(this);
		expressionView.getSettings().setJavaScriptEnabled(true);
		expressionView.loadUrl("file:///android_res/raw/index.htm");
		linearLayout.addView(expressionView);
		
		Button button=new Button(this);
		button.setText("save");
		LinearLayout.LayoutParams lp1=new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.MATCH_PARENT);
		lp1.gravity=Gravity.CENTER_HORIZONTAL;
		button.setLayoutParams(lp1);
		button.setHeight(120);
		button.setWidth(220);
		button.setOnClickListener(new View.OnClickListener(){public void onClick(View view){
			expressionView.setDrawingCacheEnabled(true);
			Bitmap bitmap=Bitmap.createBitmap(expressionView.getDrawingCache());
			expressionView.setDrawingCacheEnabled(false);
			Intent intent=new Intent("android.intent.action.SEND");
			intent.setType("image/jpeg");
			intent.putExtra("android.intent.extra.STREAM",Uri.parse(MediaStore.Images.Media.insertImage(getContentResolver(),bitmap,String.valueOf((long)System.currentTimeMillis()),"expression")));
			MainActivity.this.startActivity(Intent.createChooser(intent,""));
		}});
		linearLayout.addView(button);
		
		ScrollView scrollView=new ScrollView(this);
		scrollView.setBackgroundColor(new Color().parseColor("#e1e8f0"));
		scrollView.addView(linearLayout);
		setContentView(scrollView);
	}
}

