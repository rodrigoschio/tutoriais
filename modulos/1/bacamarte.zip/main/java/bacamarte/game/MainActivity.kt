package bacamarte.game

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import java.util.Random
import java.util.Timer
import java.util.TimerTask

class MainActivity : Activity() {
    override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)
        setContentView(Bacamarte(this))
    }
}

class Bacamarte(context: Context?) : View(context) {
    var heroDirection = false
    var leftButtonPressed = false
    var rightButtonPressed = false
    var bulletDirection = false
    var bulletActive = false
    var alive = true
    var heroPosition = 10
    var altura = 0
    var bulletPosition = 0
    var bulletAltura = 0
    var pontos = 0
    var screenWidth = 0f
    var screenHeight = 0f
    var fractionScreenSize = 0f
    var leftButton: Bitmap? = null
    var rightButton: Bitmap? = null
    var jumpButton: Bitmap? = null
    var bulletButton: Bitmap? = null
    var heroLeft: Bitmap? = null
    var heroRight: Bitmap? = null
    var skull: Bitmap? = null
    var bg: Bitmap? = null
    var bullets = arrayOfNulls<BulletEnemy>(10)
    var paint: Paint = Paint()
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawBitmap(bg!!, 0f, 0f, paint)
        paint.color = Color.rgb(160, 160, 160)
        canvas.drawRect(0f, (0.74 * screenHeight).toFloat(), screenWidth, screenHeight, paint)
        canvas.drawRect(
            0f,
            (0.52 * screenHeight).toFloat(),
            fractionScreenSize * 100,
            (0.53 * screenHeight).toFloat(),
            paint
        )
        canvas.drawRect(
            screenWidth - fractionScreenSize * 100,
            (0.52 * screenHeight).toFloat(),
            screenWidth,
            (0.53 * screenHeight).toFloat(),
            paint
        )
        if (!alive) {
            paint.color = Color.rgb(65, 65, 65)
            paint.color = Color.rgb(65, 65, 65)
            canvas.drawRect(0.0f, 0.0f, screenWidth, screenHeight, paint)
            paint.color = Color.rgb(2, 2, 2)
            paint.textAlign = Paint.Align.RIGHT
            paint.textSize = (0.16 * screenHeight).toFloat()
            canvas.drawText(
                "$pontos x",
                (0.85 * screenWidth).toFloat(),
                (0.22 * screenHeight).toFloat(),
                paint
            )
            canvas.drawBitmap(
                skull!!,
                (0.87 * screenWidth).toFloat(),
                (0.08 * screenHeight).toFloat(),
                paint
            )
        } else {
            canvas.drawBitmap(
                leftButton!!,
                (0.02 * screenWidth).toFloat(),
                (0.79 * screenHeight).toFloat(),
                paint
            )
            canvas.drawBitmap(
                rightButton!!,
                (0.02 * screenWidth + 120 * fractionScreenSize).toFloat(),
                (0.79 * screenHeight).toFloat(),
                paint
            )
            canvas.drawBitmap(
                jumpButton!!,
                (0.994 * screenWidth - 120 * fractionScreenSize).toFloat(),
                (0.79 * screenHeight).toFloat(),
                paint
            )
            canvas.drawBitmap(
                bulletButton!!,
                (0.902 * screenWidth - 120 * fractionScreenSize).toFloat(),
                (0.81 * screenHeight).toFloat(),
                paint
            )
            if (heroDirection) canvas.drawBitmap(
                heroLeft!!,
                screenWidth / 24 * (heroPosition - 1),
                (0.44 * screenHeight - 5 * fractionScreenSize * altura).toFloat(),
                paint
            ) else canvas.drawBitmap(
                heroRight!!,
                screenWidth / 24 * (heroPosition - 1),
                (0.44 * screenHeight - 5 * fractionScreenSize * altura).toFloat(),
                paint
            )
            if (!(bulletAltura < 9 && bulletPosition == 0 && bulletActive)) canvas.drawBitmap(
                heroRight!!, screenWidth / 24 * -1, (0.44 * screenHeight).toFloat(), paint
            )
            if (!(bulletAltura < 9 && bulletPosition == 22 && bulletActive)) canvas.drawBitmap(
                heroLeft!!, screenWidth / 24 * 22, (0.44 * screenHeight).toFloat(), paint
            )
            if (!(bulletAltura > 18 && bulletPosition == 0 && bulletActive)) canvas.drawBitmap(
                heroRight!!, screenWidth / 24 * -1, (0.228 * screenHeight).toFloat(), paint
            )
            if (!(bulletAltura > 18 && bulletPosition == 22 && bulletActive)) canvas.drawBitmap(
                heroLeft!!, screenWidth / 24 * 22, (0.228 * screenHeight).toFloat(), paint
            )
            paint.color = Color.rgb(2, 2, 2)
            if (bulletActive) canvas.drawCircle(
                (bulletPosition - 1) * screenWidth / 24 + (screenWidth / 12),
                (0.64 * screenHeight - 5 * fractionScreenSize * bulletAltura).toFloat(),
                screenWidth / 80,
                paint
            )
            for (n in 0..9) if (bullets[n]!!.active) if (bullets[n]!!.position > 0 || bullets[n]!!.position < 22) canvas.drawCircle(
                (bullets[n]!!.position - 1) * screenWidth / 24 + (screenWidth / 12),
                (0.64 * screenHeight - 5 * fractionScreenSize * bullets[n]!!.altura).toFloat(),
                screenWidth / 80,
                paint
            )
        }
    }

    override fun onSizeChanged(
        newWidth: Int,
        newHeight: Int,
        oldWidth: Int,
        oldHeight: Int
    ) {
        super.onSizeChanged(newWidth, newHeight, oldWidth, oldHeight)
        screenWidth = newWidth.toFloat()
        screenHeight = newHeight.toFloat()
        fractionScreenSize = screenHeight / 600
        for (n in 0..9) bullets[n] = BulletEnemy()
        val resources = resources
        bg = Bitmap.createScaledBitmap(
            BitmapFactory.decodeResource(resources, R.drawable.bg),
            screenWidth.toInt(),
            screenHeight.toInt(),
            true
        )
        skull = Bitmap.createScaledBitmap(
            BitmapFactory.decodeResource(resources, R.drawable.skull),
            (100 * fractionScreenSize).toInt(),
            (100 * fractionScreenSize).toInt(),
            true
        )
        leftButton = Bitmap.createScaledBitmap(
            BitmapFactory.decodeResource(resources, R.drawable.left),
            (100 * fractionScreenSize).toInt(),
            (100 * fractionScreenSize).toInt(),
            true
        )
        rightButton = Bitmap.createScaledBitmap(
            BitmapFactory.decodeResource(resources, R.drawable.right),
            (100 * fractionScreenSize).toInt(),
            (100 * fractionScreenSize).toInt(),
            true
        )
        jumpButton = Bitmap.createScaledBitmap(
            BitmapFactory.decodeResource(resources, R.drawable.jump),
            (100 * fractionScreenSize).toInt(),
            (100 * fractionScreenSize).toInt(),
            true
        )
        bulletButton = Bitmap.createScaledBitmap(
            BitmapFactory.decodeResource(resources, R.drawable.bullet),
            (80 * fractionScreenSize).toInt(),
            (80 * fractionScreenSize).toInt(),
            true
        )
        heroLeft = Bitmap.createScaledBitmap(
            BitmapFactory.decodeResource(resources, R.drawable.heroleft),
            (180 * fractionScreenSize).toInt(),
            (180 * fractionScreenSize).toInt(),
            true
        )
        heroRight = Bitmap.createScaledBitmap(
            BitmapFactory.decodeResource(resources, R.drawable.heroright),
            (180 * fractionScreenSize).toInt(),
            (180 * fractionScreenSize).toInt(),
            true
        )
        Timer().schedule(gameLoop, 0, 50)
    }

    override fun onTouchEvent(motionEvent: MotionEvent): Boolean {
        val x = motionEvent.x
        val y = motionEvent.y
        if (motionEvent.action == MotionEvent.ACTION_UP) {
            rightButtonPressed = false
            leftButtonPressed = false
        } else {
            if (!alive && x > 0.8 * screenWidth && y < 0.60 * screenHeight) {
                pontos = 0
                alive = true
                bulletActive = false
                heroPosition = 10
                heroDirection = false
                altura = 0
                for (n in 0..9) bullets[n] = BulletEnemy()
            } else {
                if (x < 0.02 * screenWidth + 120 * fractionScreenSize && y > 0.74 * screenHeight) {
                    heroDirection = true
                    leftButtonPressed = true
                }
                if (x > 0.02 * screenWidth + 120 * fractionScreenSize && x < 0.2 * screenWidth + 120 * fractionScreenSize && y > 0.74 * screenHeight) {
                    heroDirection = false
                    rightButtonPressed = true
                }
                if (x > screenWidth - 0.02 * screenWidth - 120 * fractionScreenSize && y > 0.74 * screenHeight) {
                    if (altura == 0) altura = 5
                }
                if (x < screenWidth - 0.02 * screenWidth - 120 * fractionScreenSize && x > screenWidth - 0.2 * screenWidth - 120 * fractionScreenSize && y > 0.74 * screenHeight && !bulletActive) {
                    bulletPosition = heroPosition
                    bulletDirection = heroDirection
                    bulletAltura = altura
                    bulletActive = true
                }
            }
        }
        return true
    }

    var gameLoop: TimerTask = object : TimerTask() {
        override fun run() {
            if (alive) {
                if (rightButtonPressed && heroPosition < 22) heroPosition++
                if (leftButtonPressed && heroPosition > 1) heroPosition--
                if (altura % 4 == 1) altura += 4
                if (altura % 4 == 3) altura -= 4
                if (altura > 28) altura = 31
                if (altura < 2) altura = 0
                if (bulletActive) if (bulletDirection) bulletPosition-- else bulletPosition++
                if (bulletPosition < -1 || bulletPosition > 23) {
                    if (bulletActive) pontos++
                    bulletActive = false
                }
            }
            var difficulty = 0.03f
            if (pontos > 5) difficulty = 0.07f
            if (pontos > 15) difficulty = 0.13f
            if (Random().nextFloat() < difficulty) {
                var x = 0
                while (bullets[x]!!.active) x++
                if (x < 10) {
                    if (Random().nextBoolean()) {
                        bullets[x]!!.position = 0
                        bullets[x]!!.direction = false
                    } else {
                        bullets[x]!!.position = 22
                        bullets[x]!!.direction = true
                    }
                    bullets[x]!!.altura = if (Random().nextBoolean()) 0 else 25
                    bullets[x]!!.active = true
                    for (m in 0..9)
                        if (m != x && bullets[m]!!.active && (bullets[m]!!.position == 22 || bullets[m]!!.position == 21 || bullets[m]!!.position == 20 || bullets[m]!!.position == 2 || bullets[m]!!.position == 1 || bullets[m]!!.position == 0))
                            bullets[x]!!.active = false
                }
            }
            for (n in 0..9) if (bullets[n]!!.active) {
                bullets[n]!!.delay++
                if(bullets[n]!!.delay == 3) bullets[n]!!.delay = 0

                if (bullets[n]!!.delay == 2) {
                    if (bullets[n]!!.direction) bullets[n]!!.position--
                    else bullets[n]!!.position++
                }
                if (bullets[n]!!.position < -1 || bullets[n]!!.position > 23) bullets[n]!!.active =
                    false
                if (bullets[n]!!.position == heroPosition && altura < 12 == bullets[n]!!.altura < 12) alive =
                    false
            }
            invalidate()
        }
    }
}

class BulletEnemy {
    var position = 0
    var altura = 0
    var delay = 0
    var direction = false
    var active = false
}
