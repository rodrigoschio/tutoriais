package zombie.waves;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends Activity {
	protected void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(new ZombieWaves(this));
	}
}

class ZombieWaves extends View {
	Joe joe = new Joe();
	Zombie[] zombie = new Zombie[10];

	Canvas canvas;
	Paint paint;

	boolean leftButtonPressed, rightButtonPressed;

	int qttZombies, endScreenDelay;

	float screenHeight, screenWidth, fractionScreenSize;

	Bitmap heartLeft, heartRight;
	Bitmap leftButton, rightButton, attackButton;
	Bitmap bg, skull;

	Bitmap joeIdleLeft, joeIdleRight;
	Bitmap joeWalkingLeft, joeWalkingRight;
	Bitmap joeAttackLeft, joeAttackRight;
	Bitmap joeInjury;

	Bitmap zombieWalkingLeft, zombieWalkingRight;
	Bitmap zombieAttackLeft, zombieAttackRight;
	Bitmap zombieInjury;

	public ZombieWaves(Context context) {
		super(context);
	}

	void drawStage() {
		canvas.drawBitmap(bg, 0f, 0f, paint);
		paint.setColor(Color.rgb(130, 130, 130));
		canvas.drawRect(0, (float) (0.75 * screenHeight), screenWidth, screenHeight, paint);
	}

	void drawButtons() {
		canvas.drawBitmap(leftButton, (int) (0.02 * screenWidth), (int) (0.77 * screenHeight), paint);
		canvas.drawBitmap(rightButton, (int) (0.02 * screenWidth + 120 * fractionScreenSize), (int) (0.77 * screenHeight), paint);
		canvas.drawBitmap(attackButton, (int) (0.92 * screenWidth - 120 * fractionScreenSize), (int) (0.77 * screenHeight), paint);
	}

	void drawEnergyBar() {
		for (int i = 0; i < joe.energy; i++) {
			if (i % 2 == 0)
				canvas.drawBitmap(heartLeft, (int) ((0.062 * screenHeight) + 53 * (i * fractionScreenSize)), (int) (0.05 * screenHeight), paint);
			else
				canvas.drawBitmap(heartRight, (int) ((0.062 * screenHeight) + 53 * (i * fractionScreenSize)), (int) (0.05 * screenHeight), paint);
		}
	}

	void drawJoe() {
		Bitmap imgJoe;
		if (joe.hittedDelay > 0) imgJoe = joeInjury;
		else if (joe.direction) {
			if (joe.attackDelay > 0) imgJoe = joeAttackLeft;
			else {
				if (leftButtonPressed) imgJoe = joeWalkingLeft;
				else imgJoe = joeIdleLeft;
			}
		} else {
			if (joe.attackDelay > 0) imgJoe = joeAttackRight;
			else {
				if (rightButtonPressed) imgJoe = joeWalkingRight;
				else imgJoe = joeIdleRight;
			}
		}
		canvas.drawBitmap(imgJoe, (int) (joe.position * screenWidth / 30), (int) (0.54 * screenHeight), paint);
	}

	void drawZombie(Zombie z) {
		Bitmap imgZombie;
		if (z.hittedDelay != 0) imgZombie = zombieInjury;
		else if (z.attackDelay < 5 && (z.position == joe.position + 2 || z.position == joe.position - 2)) {
			if (z.direction) imgZombie = zombieAttackLeft;
			else imgZombie = zombieAttackRight;
		} else {
			if (z.direction) imgZombie = zombieWalkingLeft;
			else imgZombie = zombieWalkingRight;
		}
		canvas.drawBitmap(imgZombie, (int) (z.position * screenWidth / 30), (int) (0.54 * screenHeight), paint);
	}

	void drawScore() {
		paint.setColor(Color.rgb(65, 65, 65));
		canvas.drawRect(0.0f, 0.0f, screenWidth, screenHeight, paint);
		paint.setColor(Color.rgb(2, 2, 2));
		paint.setTextAlign(Paint.Align.RIGHT);
		paint.setTextSize((float) (0.16 * (double) screenHeight));
		canvas.drawText(joe.score + " x", (float) ((0.85 * (double) screenWidth)), (float) ((0.22 * (double) screenHeight)), paint);
		canvas.drawBitmap(skull, (float) ((0.87 * (double) screenWidth)), (float) ((0.08 * (double) screenHeight)), paint);
	}

	void init() {
		joe = new Joe();

		qttZombies = 5;
		for (int z = 0; z < 10; z++) zombie[z] = new Zombie();
		for (int z = 0; z < qttZombies; z++) setZombiePosition(zombie[z]);

		endScreenDelay = 22;
	}

	void joePunch() {
		for (int z = 0; z < qttZombies; z++) {
			if (joe.attackDelay == 4 && zombie[z].hittedDelay == 0 && ((!joe.direction && zombie[z].position == joe.position + 2) || (joe.direction && zombie[z].position == joe.position - 2))) {
				zombie[z].hittedDelay = 4;
				zombie[z].attackDelay = 10;
				zombie[z].energy--;
			}
		}
		if (joe.attackDelay > 0) joe.attackDelay--;
	}

	void zombieTake() {
		for (int z = 0; z < qttZombies; z++) {
			if (zombie[z].hittedDelay > 0) zombie[z].hittedDelay--;
			if (zombie[z].energy == 0) {
				setZombiePosition(zombie[z]);
				joe.score++;
				if (joe.score == 12) {
					qttZombies = 10;
					for (int j = 5; j < qttZombies; ++j) setZombiePosition(zombie[j]);
				}
			}
		}
	}

	void zombieWalk() {
		for (int z = 0; z < qttZombies; z++) {
			zombie[z].moveDelay--;
			if (zombie[z].moveDelay < 1) {
				if (zombie[z].direction) {
					if (zombie[z].position > joe.position + 2) zombie[z].position--;
					else zombie[z].position = joe.position + 2;
				} else {
					if (zombie[z].position < joe.position - 2) zombie[z].position++;
					else zombie[z].position = joe.position - 2;
				}
				zombie[z].moveDelay = 6;
			}
		}
	}

	void joeStepLeft() {
		boolean canMove = true;
		for (int z = 0; z < qttZombies; z++)
			if (zombie[z].position == joe.position - 2) canMove = false;
		if (canMove) joe.position--;
	}

	void joeStepRight() {
		boolean canMove = true;
		for (int z = 0; z < qttZombies; z++)
			if (zombie[z].position == joe.position + 2) canMove = false;
		if (canMove) joe.position++;
	}

	void zombiePunch() {
		for (int z = 0; z < qttZombies; z++) {
			if (zombie[z].hittedDelay == 0 && (zombie[z].position == joe.position + 2 || zombie[z].position == joe.position - 2))
				zombie[z].attackDelay--;
			if (zombie[z].attackDelay == 0) zombie[z].attackDelay = 20;
			if (zombie[z].attackDelay == 4 && joe.hittedDelay == 0) {
				joe.hittedDelay = 5;
				joe.energy--;
			}
		}
		if (joe.energy < 1) endScreenDelay = 22;
	}

	void setZombiePosition(Zombie z) {
		z.moveDelay = new Random().nextInt(12);
		z.direction = new Random().nextBoolean();
		z.attackDelay = 10;
		z.energy = 3;
		int padding;
		if (joe.score < 12) padding = 6;
		else padding = 3;
		if (z.direction) {
			int far = 30;
			for (int n = 0; n < qttZombies; n++)
				if (zombie[n].position > far) far = zombie[n].position;
			z.position = far + padding + new Random().nextInt(padding) + 1;
		} else {
			int far = 3;
			for (int n = 0; n < qttZombies; n++)
				if (zombie[n].position < far) far = zombie[n].position;
			z.position = far - padding - new Random().nextInt(padding) - 1;
		}
	}

	TimerTask gameLoop = new TimerTask() {
		public void run() {
			if (joe.energy > 0) {
				joePunch();
				zombieTake();
				zombieWalk();
				if (joe.hittedDelay > 0) joe.hittedDelay--;
				if (leftButtonPressed && joe.position > 2 && joe.hittedDelay == 0) joeStepLeft();
				if (rightButtonPressed && joe.position < 26 && joe.hittedDelay == 0) joeStepRight();
				zombiePunch();
			} else if (endScreenDelay > 0) endScreenDelay--;
			invalidate();//call onDraw
		}
	};

	public boolean onTouchEvent(MotionEvent motionEvent) {
		float x = motionEvent.getX();
		float y = motionEvent.getY();
		if (joe.energy == 0 && endScreenDelay == 0 && x > 0.8 * screenWidth && y < 0.60 * screenHeight) {
			init();
		} else {
			if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
				rightButtonPressed = false;
				leftButtonPressed = false;
			} else {
				if (x < (0.02 * screenWidth) + (120 * fractionScreenSize) && y > 0.74 * screenHeight) {
					joe.direction = true;
					leftButtonPressed = true;
				}
				if (x > (0.02 * screenWidth) + (120 * fractionScreenSize) && x < (0.02 * screenWidth) + (300 * fractionScreenSize) && y > 0.74 * screenHeight) {
					joe.direction = false;
					rightButtonPressed = true;
				}
				if (x > 0.8 * screenWidth && y > 0.74 * screenHeight && joe.attackDelay == 0 && joe.hittedDelay == 0) {
					joe.attackDelay = 4;
				}
			}
		}
		return true;
	}

	protected void onDraw(Canvas c) {
		super.onDraw(c);
		canvas = c;
		paint = new Paint();
		if (endScreenDelay == 0) drawScore();
		else {
			drawStage();
			drawButtons();
			drawEnergyBar();
			drawJoe();
			for (int z = 0; z < qttZombies; z++)
				drawZombie(zombie[z]);
		}
	}

	protected void onSizeChanged(int newWidth, int newHeight, int oldWidth, int oldHeight) { //called when app start
		super.onSizeChanged(newWidth, newHeight, oldWidth, oldHeight);
		screenWidth = newWidth;
		screenHeight = newHeight;
		fractionScreenSize = screenHeight / 600;

		Resources resources = getResources();

		heartLeft = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.heartleft), (int) (48 * fractionScreenSize), (int) (54 * fractionScreenSize), true);
		heartRight = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.heartright), (int) (48 * fractionScreenSize), (int) (54 * fractionScreenSize), true);

		leftButton = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.left), (int) (120 * fractionScreenSize), (int) (120 * fractionScreenSize), true);
		rightButton = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.right), (int) (120 * fractionScreenSize), (int) (120 * fractionScreenSize), true);
		attackButton = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.attack), (int) (120 * fractionScreenSize), (int) (120 * fractionScreenSize), true);

		joeIdleLeft = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.joeidleleft), (int) (130 * fractionScreenSize), (int) (130 * fractionScreenSize), true);
		joeIdleRight = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.joeidleright), (int) (130 * fractionScreenSize), (int) (130 * fractionScreenSize), true);
		joeWalkingLeft = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.joewalkingleft), (int) (130 * fractionScreenSize), (int) (130 * fractionScreenSize), true);
		joeWalkingRight = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.joewalkingright), (int) (130 * fractionScreenSize), (int) (130 * fractionScreenSize), true);
		joeAttackLeft = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.joeattackleft), (int) (130 * fractionScreenSize), (int) (130 * fractionScreenSize), true);
		joeAttackRight = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.joeattackright), (int) (130 * fractionScreenSize), (int) (130 * fractionScreenSize), true);
		joeInjury = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.joeinjury), (int) (130 * fractionScreenSize), (int) (130 * fractionScreenSize), true);

		zombieWalkingLeft = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.zombiewalkingleft), (int) (130 * fractionScreenSize), (int) (130 * fractionScreenSize), true);
		zombieWalkingRight = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.zombiewalkingright), (int) (130 * fractionScreenSize), (int) (130 * fractionScreenSize), true);
		zombieInjury = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.zombieinjury), (int) (130 * fractionScreenSize), (int) (140 * fractionScreenSize), true);
		zombieAttackLeft = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.zombieattackleft), (int) (130 * fractionScreenSize), (int) (130 * fractionScreenSize), true);
		zombieAttackRight = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.zombieattackright), (int) (130 * fractionScreenSize), (int) (130 * fractionScreenSize), true);

		bg = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.bg), (int) screenWidth, (int) screenHeight, true);
		skull = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.skull), (int) (100 * fractionScreenSize), (int) (100 * fractionScreenSize), true);

		init();
		new Timer().schedule(gameLoop, 0, 50);
	}
}

class Joe {
	boolean direction;
	int position = 12;
	int energy = 4;
	int score = 0;
	int attackDelay = 0;
	int hittedDelay = 0;
}

class Zombie {
	boolean direction;
	int moveDelay;
	int attackDelay;
	int hittedDelay = 0;
	int position = 12;
	int energy;
}
