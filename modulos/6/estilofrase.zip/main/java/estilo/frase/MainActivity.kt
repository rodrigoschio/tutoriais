package estilo.frase

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore.Images
import android.view.View
import android.webkit.WebView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toolbar

class MainActivity : Activity() {
    var wv: WebView? = null
    fun addBtn(view: View, orientacao: Boolean, caption: String?, funcao: View.OnClickListener?) {
        val botao = Button(this)
        botao.text = caption
        botao.gravity = 3
        botao.setPadding(if (orientacao) 40 else 20, 20, 20, 20)
        botao.layoutParams = Toolbar.LayoutParams(if (orientacao) -1 else -2, -2)
        botao.setOnClickListener(funcao)
        (view as LinearLayout).addView(botao)
    }

    override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)

        val linearlayout = LinearLayout(this)
        linearlayout.layoutParams = Toolbar.LayoutParams(-1, -1)
        linearlayout.orientation = LinearLayout.VERTICAL
        linearlayout.setPadding(12, 12, 12, 0)

        val layoutparams = Toolbar.LayoutParams(-1, resources.displayMetrics.heightPixels / 2)
        layoutparams.setMargins(0, 0, 0, 12)

        wv = WebView(this)
        wv!!.layoutParams = layoutparams
        wv!!.settings.javaScriptEnabled = true
        wv!!.settings.domStorageEnabled = true
        wv!!.loadUrl(getString(R.string.location))
        linearlayout.addView(wv)

        val ll2 = LinearLayout(this)
        ll2.layoutParams = Toolbar.LayoutParams(-1, -1)
        ll2.orientation = LinearLayout.HORIZONTAL

        addBtn(ll2, false, getString(R.string.color)) { wv!!.loadUrl("javascript:geraStilo(false,true,false,false);") }
        addBtn(ll2, false, getString(R.string.text)) { wv!!.loadUrl("javascript:geraStilo(false,false,true,false);") }
        addBtn(ll2, false, getString(R.string.frame)) { wv!!.loadUrl("javascript:geraStilo(false,false,false,true);") }
        linearlayout.addView(ll2)

        addBtn(linearlayout, true, getString(R.string.edit)) { wv!!.loadUrl("javascript:inicio();") }
        addBtn(linearlayout, true, getString(R.string.frase)) { wv!!.loadUrl("javascript:geraStilo(true,false,false,false);") }
        addBtn(linearlayout, true, getString(R.string.save)) {
            wv!!.isDrawingCacheEnabled = true
            val bitmap = Bitmap.createBitmap(wv!!.drawingCache)
            wv!!.isDrawingCacheEnabled = false
            val intent = Intent("android.intent.action.SEND")
            intent.setType("image/jpeg")
            intent.putExtra("android.intent.extra.STREAM", Uri.parse(Images.Media.insertImage(contentResolver,bitmap,System.currentTimeMillis().toString(),"styled phrase")))
            startActivity(Intent.createChooser(intent, ""))
        }

        val scrollview = ScrollView(this)
        scrollview.layoutParams = Toolbar.LayoutParams(-1, -1)
        scrollview.addView(linearlayout)
        setContentView(scrollview)
    }
}
