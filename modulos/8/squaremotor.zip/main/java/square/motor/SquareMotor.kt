package square.motor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import java.util.Timer
import java.util.TimerTask

class SquareMotor(context: Context?) : View(context) {
    var paint = Paint()
    var btnPrevious: Bitmap? = null
    var btnNext: Bitmap? = null
    var logo: Bitmap? = null
    var btncw: Bitmap? = null
    var btnccw: Bitmap? = null
    var star: Bitmap? = null
    var opaqueStar: Bitmap? = null
    var menu: Bitmap? = null
    var car = arrayOfNulls<Bitmap>(36)
    var tile = arrayOfNulls<Bitmap>(21)
    var numbers = arrayOfNulls<Bitmap>(6)
    var miniTiles = arrayOfNulls<Bitmap>(21)
    var screenWidth = 0f
    var screenHeight = 0f
    var carPositionX = 0f
    var carPositionY = 0f
    var fractionScreenSize = 0f
    var miniTilesSize = 0f
    var cwPressed = false
    var ccwPressed = false
    var walkOut = false
    var angle3 = 0
    var time = -5
    var stage = 0
    var qttStages = 24
    var maxSpeed = intArrayOf(8, 9, 10, 10, 11, 11, 11, 12, 12, 12, 13, 13, 13, 14, 14, 14, 14, 15, 15, 15, 15, 16, 16, 16)
    var startAngle = intArrayOf(0, 56, 28, 82, 0, 56, 56, 28, 56, 56, 28, 28, 28, 28, 0, 56, 28, 56, 82, 56, 82, 56, 0, 0)
    var stageTimeLimit = intArrayOf(740, 540, 800, 710, 980, 980, 760, 1030, 1020, 1300, 1080, 1700, 1080, 620, 1570, 1180, 1410, 1900, 1460, 840, 2000, 1580, 2160, 1520)
    var stageStarts = arrayOf(
        intArrayOf(6, 2),
        intArrayOf(0, 2),
        intArrayOf(4, 2),
        intArrayOf(0, 4),
        intArrayOf(2, 0),
        intArrayOf(4, 0),
        intArrayOf(0, 4),
        intArrayOf(2, 0),
        intArrayOf(0, 4),
        intArrayOf(0, 6),
        intArrayOf(0, 0),
        intArrayOf(6, 8),
        intArrayOf(0, 0),
        intArrayOf(4, 0),
        intArrayOf(4, 10),
        intArrayOf(2, 0),
        intArrayOf(12, 0),
        intArrayOf(0, 8),
        intArrayOf(4, 4),
        intArrayOf(4, 4),
        intArrayOf(0, 10),
        intArrayOf(0, 0),
        intArrayOf(4, 14),
        intArrayOf(12, 0)
    )
    var stageEnds = arrayOf(
        intArrayOf(6, 0),
        intArrayOf(0, 0),
        intArrayOf(2, 2),
        intArrayOf(3, 2),
        intArrayOf(4, 0),
        intArrayOf(2, 0),
        intArrayOf(0, 6),
        intArrayOf(0, 0),
        intArrayOf(0, 6),
        intArrayOf(0, 4),
        intArrayOf(2, 0),
        intArrayOf(6, 6),
        intArrayOf(2, 0),
        intArrayOf(2, 0),
        intArrayOf(6, 10),
        intArrayOf(0, 0),
        intArrayOf(10, 0),
        intArrayOf(0, 10),
        intArrayOf(6, 4),
        intArrayOf(4, 6),
        intArrayOf(2, 10),
        intArrayOf(0, 2),
        intArrayOf(6, 14),
        intArrayOf(4, 4)
    )
    var course = arrayOf(
        arrayOf(intArrayOf(12, 4, 6), intArrayOf(2, 0, 1), intArrayOf(2, 0, 1), intArrayOf(2, 0, 1), intArrayOf(2, 0, 1), intArrayOf(2, 0, 1), intArrayOf(19, 0, 16)),
        arrayOf(intArrayOf(14, 0, 13), intArrayOf(1, 0, 2), intArrayOf(1, 0, 2), intArrayOf(1, 0, 2), intArrayOf(1, 0, 2), intArrayOf(9, 4, 7)),
        arrayOf(intArrayOf(11, 3, 3, 3, 5), intArrayOf(1, 0, 0, 0, 2), intArrayOf(1, 0, 20, 4, 7), intArrayOf(1, 0, 0, 0, 0), intArrayOf(1, 0, 15, 3, 5), intArrayOf(1, 0, 0, 0, 2), intArrayOf(9, 4, 4, 4, 7)),
        arrayOf(intArrayOf(12, 4, 4, 4, 17), intArrayOf(2, 0, 0, 0, 0), intArrayOf(2, 0, 0, 0, 0), intArrayOf(2, 0, 20, 4, 6), intArrayOf(2, 0, 0, 0, 1), intArrayOf(2, 0, 0, 0, 1), intArrayOf(10, 3, 3, 3, 8)),
        arrayOf(intArrayOf(11, 3, 5, 0, 11, 3, 5), intArrayOf(1, 0, 2, 0, 1, 0, 2), intArrayOf(16, 0, 10, 3, 8, 0, 2), intArrayOf(0, 0, 0, 0, 0, 0, 2), intArrayOf(14, 0, 12, 4, 6, 0, 2), intArrayOf(1, 0, 2, 0, 1, 0, 2), intArrayOf(9, 4, 7, 0, 9, 4, 7)),
        arrayOf(intArrayOf(12, 4, 6, 0, 12, 4, 6), intArrayOf(2, 0, 1, 0, 2, 0, 1), intArrayOf(19, 0, 9, 4, 7, 0, 1), intArrayOf(0, 0, 0, 0, 0, 0, 1), intArrayOf(13, 0, 11, 3, 5, 0, 1), intArrayOf(2, 0, 1, 0, 2, 0, 1), intArrayOf(10, 3, 8, 0, 10, 3, 8)),
        arrayOf(intArrayOf(0, 0, 0, 0, 13, 0, 14), intArrayOf(0, 0, 0, 0, 2, 0, 1), intArrayOf(0, 0, 12, 4, 7, 0, 1), intArrayOf(0, 0, 2, 0, 0, 0, 1), intArrayOf(12, 4, 7, 0, 11, 3, 8), intArrayOf(2, 0, 0, 0, 1, 0, 0), intArrayOf(10, 3, 3, 3, 8, 0, 0)),
        arrayOf(intArrayOf(20, 4, 4, 4, 4, 4, 4, 6), intArrayOf(0, 0, 0, 0, 0, 0, 0, 1), intArrayOf(15, 3, 3, 3, 3, 5, 0, 1), intArrayOf(0, 0, 0, 0, 0, 2, 0, 1), intArrayOf(12, 4, 4, 4, 4, 7, 0, 1), intArrayOf(2, 0, 0, 0, 0, 0, 0, 1), intArrayOf(10, 3, 3, 3, 3, 3, 3, 8)),
        arrayOf(intArrayOf(12, 4, 6, 0, 13, 0, 14, 0, 12, 4, 6), intArrayOf(2, 0, 1, 0, 2, 0, 1, 0, 2, 0, 1), intArrayOf(2, 0, 9, 4, 7, 0, 9, 4, 7, 0, 1), intArrayOf(2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1), intArrayOf(10, 3, 3, 3, 3, 3, 3, 3, 3, 3, 8)),
        arrayOf(intArrayOf(11, 3, 5, 0, 14, 0, 13, 0, 11, 3, 5), intArrayOf(1, 0, 2, 0, 1, 0, 2, 0, 1, 0, 2), intArrayOf(1, 0, 10, 3, 8, 0, 10, 3, 8, 0, 2), intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2), intArrayOf(1, 0, 12, 4, 6, 0, 12, 4, 6, 0, 2), intArrayOf(1, 0, 2, 0, 1, 0, 2, 0, 1, 0, 2), intArrayOf(9, 4, 7, 0, 9, 4, 7, 0, 9, 4, 7)),
        arrayOf(intArrayOf(15, 3, 5, 0, 11, 3, 3, 3, 5), intArrayOf(0, 0, 2, 0, 1, 0, 0, 0, 2), intArrayOf(14, 0, 2, 0, 9, 4, 6, 0, 2), intArrayOf(1, 0, 2, 0, 0, 0, 1, 0, 2), intArrayOf(1, 0, 10, 3, 3, 3, 8, 0, 2), intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 2), intArrayOf(9, 4, 4, 4, 4, 4, 4, 4, 7)),
        arrayOf(intArrayOf(12, 4, 4, 4, 6, 0, 12, 4, 6, 0, 12, 4, 4, 4, 6), intArrayOf(2, 0, 0, 0, 1, 0, 2, 0, 1, 0, 2, 0, 0, 0, 1), intArrayOf(2, 0, 11, 3, 8, 0, 2, 0, 1, 0, 10, 3, 5, 0, 1), intArrayOf(2, 0, 1, 0, 0, 0, 2, 0, 1, 0, 0, 0, 2, 0, 1), intArrayOf(2, 0, 9, 4, 4, 4, 7, 0, 9, 4, 4, 4, 7, 0, 1), intArrayOf(2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1), intArrayOf(10, 3, 3, 3, 3, 3, 18, 0, 15, 3, 3, 3, 3, 3, 8)),
        arrayOf(intArrayOf(15, 3, 5, 0, 11, 3, 5), intArrayOf(0, 0, 2, 0, 1, 0, 2), intArrayOf(14, 0, 2, 0, 1, 0, 2), intArrayOf(1, 0, 2, 0, 1, 0, 2), intArrayOf(1, 0, 2, 0, 1, 0, 2), intArrayOf(1, 0, 2, 0, 1, 0, 2), intArrayOf(1, 0, 10, 3, 8, 0, 2), intArrayOf(1, 0, 0, 0, 0, 0, 2), intArrayOf(9, 4, 4, 4, 4, 4, 7)),
        arrayOf(intArrayOf(0, 0, 12, 4, 6, 0, 0), intArrayOf(0, 0, 2, 0, 1, 0, 0), intArrayOf(20, 4, 7, 0, 9, 4, 6), intArrayOf(0, 0, 0, 0, 0, 0, 1), intArrayOf(15, 3, 5, 0, 11, 3, 8), intArrayOf(0, 0, 2, 0, 1, 0, 0), intArrayOf(0, 0, 10, 3, 8, 0, 0)),
        arrayOf(intArrayOf(0, 0, 12, 4, 4, 4, 4, 4, 6, 0, 0), intArrayOf(0, 0, 2, 0, 0, 0, 0, 0, 1, 0, 0), intArrayOf(12, 4, 7, 0, 11, 3, 5, 0, 9, 4, 6), intArrayOf(2, 0, 0, 0, 1, 0, 2, 0, 0, 0, 1), intArrayOf(10, 3, 3, 3, 8, 0, 10, 3, 5, 0, 16), intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0), intArrayOf(12, 4, 4, 4, 6, 0, 12, 4, 7, 0, 14), intArrayOf(2, 0, 0, 0, 1, 0, 2, 0, 0, 0, 1), intArrayOf(10, 3, 5, 0, 9, 4, 7, 0, 11, 3, 8), intArrayOf(0, 0, 2, 0, 0, 0, 0, 0, 1, 0, 0), intArrayOf(0, 0, 10, 3, 3, 3, 3, 3, 8, 0, 0)),
        arrayOf(intArrayOf(20, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 6), intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1), intArrayOf(13, 0, 11, 3, 5, 0, 11, 3, 5, 0, 11, 3, 5, 0, 1), intArrayOf(2, 0, 1, 0, 2, 0, 1, 0, 2, 0, 1, 0, 2, 0, 1), intArrayOf(10, 3, 8, 0, 10, 3, 8, 0, 10, 3, 8, 0, 10, 3, 8)),
        arrayOf(intArrayOf(12, 4, 4, 4, 4, 4, 6), intArrayOf(2, 0, 0, 0, 0, 0, 1), intArrayOf(2, 0, 11, 3, 5, 0, 1), intArrayOf(2, 0, 1, 0, 2, 0, 1), intArrayOf(2, 0, 1, 0, 10, 3, 8), intArrayOf(2, 0, 1, 0, 0, 0, 0), intArrayOf(2, 0, 9, 4, 4, 4, 6), intArrayOf(2, 0, 0, 0, 0, 0, 1), intArrayOf(10, 3, 3, 3, 5, 0, 1), intArrayOf(0, 0, 0, 0, 2, 0, 1), intArrayOf(20, 4, 4, 4, 7, 0, 1), intArrayOf(0, 0, 0, 0, 0, 0, 1), intArrayOf(15, 3, 3, 3, 3, 3, 8)),
        arrayOf(intArrayOf(12, 4, 4, 4, 4, 4, 6, 0, 13, 0, 14), intArrayOf(2, 0, 0, 0, 0, 0, 1, 0, 2, 0, 1), intArrayOf(2, 0, 11, 3, 5, 0, 1, 0, 2, 0, 1), intArrayOf(2, 0, 1, 0, 2, 0, 1, 0, 2, 0, 1), intArrayOf(2, 0, 1, 0, 2, 0, 1, 0, 2, 0, 1), intArrayOf(2, 0, 1, 0, 2, 0, 1, 0, 2, 0, 1), intArrayOf(2, 0, 1, 0, 2, 0, 1, 0, 2, 0, 1), intArrayOf(2, 0, 1, 0, 2, 0, 1, 0, 2, 0, 1), intArrayOf(2, 0, 1, 0, 2, 0, 1, 0, 2, 0, 1), intArrayOf(2, 0, 1, 0, 2, 0, 9, 4, 7, 0, 1), intArrayOf(2, 0, 1, 0, 2, 0, 0, 0, 0, 0, 1), intArrayOf(10, 3, 8, 0, 10, 3, 3, 3, 3, 3, 8)),
        arrayOf(intArrayOf(12, 4, 4, 4, 4, 4, 4, 4, 6), intArrayOf(2, 0, 0, 0, 0, 0, 0, 0, 1), intArrayOf(2, 0, 11, 3, 3, 3, 5, 0, 1), intArrayOf(2, 0, 1, 0, 0, 0, 2, 0, 1), intArrayOf(2, 0, 9, 4, 17, 0, 2, 0, 1), intArrayOf(2, 0, 0, 0, 0, 0, 2, 0, 1), intArrayOf(10, 3, 3, 3, 18, 0, 2, 0, 1), intArrayOf(0, 0, 0, 0, 0, 0, 2, 0, 1), intArrayOf(12, 4, 4, 4, 4, 4, 7, 0, 1), intArrayOf(2, 0, 0, 0, 0, 0, 0, 0, 1), intArrayOf(10, 3, 3, 3, 3, 3, 3, 3, 8)),
        arrayOf(intArrayOf(0, 0, 0, 0, 11, 3, 5, 0, 0, 0, 0), intArrayOf(0, 0, 0, 0, 1, 0, 2, 0, 0, 0, 0), intArrayOf(0, 0, 11, 3, 8, 0, 10, 3, 5, 0, 0), intArrayOf(0, 0, 1, 0, 0, 0, 0, 0, 2, 0, 0), intArrayOf(11, 3, 8, 0, 13, 0, 14, 0, 10, 3, 5), intArrayOf(1, 0, 0, 0, 2, 0, 1, 0, 0, 0, 2), intArrayOf(9, 4, 4, 4, 7, 0, 9, 4, 4, 4, 7)),
        arrayOf(intArrayOf(12, 4, 4, 4, 4, 4, 4, 4, 4, 4, 17), intArrayOf(2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), intArrayOf(2, 0, 11, 3, 3, 3, 3, 3, 3, 3, 18), intArrayOf(2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0), intArrayOf(2, 0, 1, 0, 12, 4, 4, 4, 4, 4, 6), intArrayOf(2, 0, 1, 0, 2, 0, 0, 0, 0, 0, 1), intArrayOf(2, 0, 1, 0, 2, 0, 11, 3, 5, 0, 1), intArrayOf(2, 0, 1, 0, 2, 0, 1, 0, 2, 0, 1), intArrayOf(2, 0, 1, 0, 10, 3, 8, 0, 2, 0, 1), intArrayOf(2, 0, 1, 0, 0, 0, 0, 0, 2, 0, 1), intArrayOf(2, 0, 9, 4, 4, 4, 4, 4, 7, 0, 1), intArrayOf(2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1), intArrayOf(10, 3, 3, 3, 3, 3, 3, 3, 3, 3, 8)),
        arrayOf(intArrayOf(13, 0, 14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), intArrayOf(2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), intArrayOf(2, 0, 1, 0, 0, 12, 4, 4, 4, 4, 4, 4, 4, 6), intArrayOf(2, 0, 1, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1), intArrayOf(2, 0, 9, 4, 4, 7, 0, 0, 11, 3, 3, 3, 3, 8), intArrayOf(2, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0), intArrayOf(10, 3, 3, 3, 5, 0, 0, 0, 9, 4, 6, 0, 0, 0), intArrayOf(0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 1, 0, 0, 0), intArrayOf(12, 4, 4, 4, 7, 0, 11, 3, 5, 0, 1, 0, 0, 0), intArrayOf(2, 0, 0, 0, 0, 0, 1, 0, 2, 0, 1, 0, 0, 0), intArrayOf(10, 3, 3, 3, 3, 3, 8, 0, 2, 0, 1, 0, 0, 0), intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1, 0, 0, 0), intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 10, 3, 8, 0, 0, 0)),
        arrayOf(intArrayOf(12, 4, 4, 4, 6, 0, 12, 4, 6, 0, 12, 4, 4, 4, 6), intArrayOf(2, 0, 0, 0, 1, 0, 2, 0, 1, 0, 2, 0, 0, 0, 1), intArrayOf(2, 0, 11, 3, 8, 0, 2, 0, 1, 0, 10, 3, 5, 0, 1), intArrayOf(2, 0, 1, 0, 0, 0, 2, 0, 1, 0, 0, 0, 2, 0, 1), intArrayOf(2, 0, 9, 4, 4, 4, 7, 0, 9, 4, 4, 4, 7, 0, 16), intArrayOf(2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), intArrayOf(2, 0, 11, 3, 3, 3, 5, 0, 11, 3, 3, 3, 5, 0, 14), intArrayOf(2, 0, 1, 0, 0, 0, 2, 0, 1, 0, 0, 0, 2, 0, 1), intArrayOf(2, 0, 9, 4, 6, 0, 2, 0, 1, 0, 12, 4, 7, 0, 1), intArrayOf(2, 0, 0, 0, 1, 0, 2, 0, 1, 0, 2, 0, 0, 0, 1), intArrayOf(10, 3, 3, 3, 8, 0, 10, 3, 8, 0, 10, 3, 3, 3, 8)),
        arrayOf(intArrayOf(12, 4, 6, 0, 12, 4, 4, 4, 6), intArrayOf(2, 0, 1, 0, 2, 0, 0, 0, 1), intArrayOf(2, 0, 9, 4, 7, 0, 11, 3, 8), intArrayOf(2, 0, 0, 0, 0, 0, 1, 0, 0), intArrayOf(10, 3, 5, 0, 14, 0, 9, 4, 6), intArrayOf(0, 0, 2, 0, 1, 0, 0, 0, 1), intArrayOf(12, 4, 7, 0, 1, 0, 11, 3, 8), intArrayOf(2, 0, 0, 0, 1, 0, 1, 0, 0), intArrayOf(10, 3, 3, 3, 8, 0, 9, 4, 6), intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 1), intArrayOf(11, 3, 5, 0, 11, 3, 5, 0, 1), intArrayOf(1, 0, 2, 0, 1, 0, 2, 0, 1), intArrayOf(16, 0, 10, 3, 8, 0, 10, 3, 8))
    )

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        screenWidth = w.toFloat()
        screenHeight = h.toFloat()
        fractionScreenSize = screenHeight / 600
        stage = 0
        val typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        paint.typeface = typeface
        paint.textAlign = Paint.Align.CENTER
        val r = resources
        logo = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.logo), Math.ceil((645 * fractionScreenSize).toDouble()).toInt(), Math.ceil((450 * fractionScreenSize).toDouble()).toInt(), true)
        btnccw = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.ccw), Math.ceil((120 * fractionScreenSize).toDouble()).toInt(), Math.ceil((120 * fractionScreenSize).toDouble()).toInt(), true)
        btncw = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.cw), Math.ceil((120 * fractionScreenSize).toDouble()).toInt(), Math.ceil((120 * fractionScreenSize).toDouble()).toInt(), true)
        btnPrevious = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.prev), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), true)
        btnNext = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.prox), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), true)
        car[0] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.carro), Math.ceil((72 * fractionScreenSize).toDouble()).toInt(), Math.ceil((72 * fractionScreenSize).toDouble()).toInt(), true)
        numbers[1] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.n1), Math.ceil((240 * fractionScreenSize).toDouble()).toInt(), Math.ceil((240 * fractionScreenSize).toDouble()).toInt(), true)
        numbers[2] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.n2), Math.ceil((240 * fractionScreenSize).toDouble()).toInt(), Math.ceil((240 * fractionScreenSize).toDouble()).toInt(), true)
        numbers[3] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.n3), Math.ceil((240 * fractionScreenSize).toDouble()).toInt(), Math.ceil((240 * fractionScreenSize).toDouble()).toInt(), true)
        numbers[4] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.n4), Math.ceil((240 * fractionScreenSize).toDouble()).toInt(), Math.ceil((240 * fractionScreenSize).toDouble()).toInt(), true)
        numbers[5] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.n5), Math.ceil((240 * fractionScreenSize).toDouble()).toInt(), Math.ceil((240 * fractionScreenSize).toDouble()).toInt(), true)
        var matrix: Matrix
        for (x in 1..35) {
            matrix = Matrix()
            matrix.postRotate((x * 10).toFloat())
            car[x] = Bitmap.createBitmap(car[0]!!, 0, 0, Math.ceil((72 * fractionScreenSize).toDouble()).toInt(), Math.ceil((72 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        }
        tile[1] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.linha), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), true)
        matrix = Matrix()
        matrix.postRotate(180f)
        tile[2] = Bitmap.createBitmap(tile[1]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        matrix = Matrix()
        matrix.postRotate(90f)
        tile[3] = Bitmap.createBitmap(tile[1]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        matrix = Matrix()
        matrix.postRotate(270f)
        tile[4] = Bitmap.createBitmap(tile[1]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        tile[5] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.curvahorario), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), true)
        tile[6] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.curvaantihorario), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), true)
        matrix = Matrix()
        matrix.postRotate(90f)
        tile[7] = Bitmap.createBitmap(tile[5]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        matrix = Matrix()
        matrix.postRotate(90f)
        tile[8] = Bitmap.createBitmap(tile[6]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        matrix = Matrix()
        matrix.postRotate(180f)
        tile[9] = Bitmap.createBitmap(tile[5]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        matrix = Matrix()
        matrix.postRotate(180f)
        tile[10] = Bitmap.createBitmap(tile[6]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        matrix = Matrix()
        matrix.postRotate(270f)
        tile[11] = Bitmap.createBitmap(tile[5]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        matrix = Matrix()
        matrix.postRotate(270f)
        tile[12] = Bitmap.createBitmap(tile[6]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        tile[13] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.inicio), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), true)
        tile[14] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(r, R.drawable.chegada), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), true)
        matrix = Matrix()
        matrix.postRotate(270f)
        tile[15] = Bitmap.createBitmap(tile[13]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        matrix = Matrix()
        matrix.postRotate(180f)
        tile[16] = Bitmap.createBitmap(tile[13]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        matrix = Matrix()
        matrix.postRotate(90f)
        tile[17] = Bitmap.createBitmap(tile[13]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        matrix = Matrix()
        matrix.postRotate(90f)
        tile[18] = Bitmap.createBitmap(tile[14]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        matrix = Matrix()
        matrix.postRotate(180f)
        tile[19] = Bitmap.createBitmap(tile[14]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        matrix = Matrix()
        matrix.postRotate(270f)
        tile[20] = Bitmap.createBitmap(tile[14]!!, 0, 0, Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), Math.ceil((200 * fractionScreenSize).toDouble()).toInt(), matrix, true)
        star = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.star), (50 * fractionScreenSize).toInt(), (50 * fractionScreenSize).toInt(), true)
        opaqueStar = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.notstar), (50 * fractionScreenSize).toInt(), (50 * fractionScreenSize).toInt(), true)
        menu = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.menu), (64 * fractionScreenSize).toInt(), (64 * fractionScreenSize).toInt(), true)
        miniTilesSize = screenHeight / 18
        for (x in 1..20)
            miniTiles[x] = Bitmap.createScaledBitmap(tile[x]!!, miniTilesSize.toInt(), miniTilesSize.toInt(), true)
        Timer().schedule(gameloop, 0, 10)
    }

    var gameloop: TimerTask = object : TimerTask() {
        val deltaDistanceX = intArrayOf(0, -1, -2, -3, -4, -5, -6, -7, -8, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 8, 7, 6, 5, 4, 3, 2, 1)
        val deltaDistanceY = intArrayOf(9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6, -7, -8, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8)

        override fun run() {
            if (time >= 0) {
                time++
                if (ccwPressed) {
                    angle3--
                    if (angle3 == -3) angle3 = 105
                }
                if (cwPressed) {
                    angle3++
                    if (angle3 == 108) angle3 = 0
                }
                val upTile = intArrayOf(-1, -1)
                if (-carPositionY / 200 / fractionScreenSize > 0 && -carPositionX / 200 / fractionScreenSize > 0 && -carPositionY / 200 / fractionScreenSize < course[stage].size && -carPositionX / 200 / fractionScreenSize < course[stage][0].size && course[stage][(-carPositionY / 200 / fractionScreenSize).toInt()][(-carPositionX / 200 / fractionScreenSize).toInt()] != 0) {
                    upTile[0] = (-carPositionY / 200 / fractionScreenSize).toInt()
                    upTile[1] = (-carPositionX / 200 / fractionScreenSize).toInt()
                }
                if (upTile[0] == stageEnds[stage][0] && upTile[1] == stageEnds[stage][1]) {
                    if (!walkOut && time < stageTimeLimit[stage]) {
                        if (stage < qttStages - 1) time = -4
                        else time = -3
                    }
                    else time = -2
                } else {
                    var deltaPositionX = deltaDistanceX[angle3 / 3].toFloat()
                    var deltaPositionY = deltaDistanceY[angle3 / 3].toFloat()
                    if (upTile[0] == -1) {
                        walkOut = true
                        deltaPositionX /= 3f
                        deltaPositionY /= 3f
                    }
                    if (time > 100) carPositionX += fractionScreenSize * deltaPositionX * maxSpeed[stage] * 0.0642f
                    if (time > 100) carPositionY += fractionScreenSize * deltaPositionY * maxSpeed[stage] * 0.0642f
                    if (upTile[0] == -1 && time > stageTimeLimit[stage]) time = -2
                }
            }
            invalidate()
        }
    }

    override fun onTouchEvent(me: MotionEvent): Boolean {
        val x = me.x
        val y = me.y
        if (time == -1 && me.action == MotionEvent.ACTION_DOWN) {
            if (x < 250 * fractionScreenSize)
                stage = (stage + qttStages - 1) % qttStages
            else if (x > screenWidth - 250 * fractionScreenSize)
                stage = (stage + 1) % qttStages
            else {
                time = 0
                angle3 = startAngle[stage]
                carPositionX = (-stageStarts[stage][1] * 200 - 100) * fractionScreenSize
                carPositionY = (-stageStarts[stage][0] * 200 - 100) * fractionScreenSize
                cwPressed = false
                ccwPressed = false
                walkOut = false
            }
        }
        if (time == -4 && me.action == MotionEvent.ACTION_DOWN) {
            if(stage < qttStages - 1) stage++
            else stage = 0
        }
        if (time > 0) {
            cwPressed = false
            ccwPressed = false
            if (x < 330 * fractionScreenSize && y > screenHeight - 380 * fractionScreenSize)
                ccwPressed = true
            if (x > screenWidth - 330 * fractionScreenSize && y > screenHeight - 380 * fractionScreenSize)
                cwPressed = true
            if (me.action == MotionEvent.ACTION_UP) {
                cwPressed = false
                ccwPressed = false
            }
            if (x > screenWidth - 130 * fractionScreenSize && y < 100 * fractionScreenSize)
                time = -1
        }
        if (time < -1 && me.action == MotionEvent.ACTION_DOWN) time = -1
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        paint.color = Color.rgb(255, 255, 255)
        canvas.drawPaint(paint)
        paint.color = Color.rgb(0, 0, 0)
        if (time == -5) {
            canvas.drawBitmap(logo!!, (screenWidth - logo!!.width) / 2, (screenHeight - logo!!.height) / 2, paint)
        } else if (time == -4) {
            canvas.drawBitmap(star!!, (screenHeight * 0.04).toFloat(), (screenHeight * 0.04).toFloat(), paint)
            canvas.drawBitmap(star!!, (screenHeight * 0.04).toFloat() + 50 * fractionScreenSize, (screenHeight * 0.04).toFloat(), paint)
            canvas.drawBitmap(star!!, (screenHeight * 0.04).toFloat() + 100 * fractionScreenSize, (screenHeight * 0.04).toFloat(), paint)
            for (x in 0..7)
                canvas.drawBitmap(tile[3]!!, x * 200 * fractionScreenSize - 100 * fractionScreenSize, (screenHeight * 0.68).toFloat(), paint)
            paint.textSize = (screenHeight * 0.160).toFloat()
            canvas.drawText(context.getString(R.string.passoudefase), screenWidth / 2, screenHeight / 2, paint)
        } else if (time == -3) {
            paint.textSize = (screenHeight * 0.18).toFloat()
            canvas.drawText(context.getString(R.string.fimdojogo1), screenWidth / 2, (screenHeight * 0.4).toFloat(), paint)
            paint.textSize = (screenHeight * 0.12).toFloat()
            canvas.drawText(context.getString(R.string.fimdojogo2), screenWidth / 2, (screenHeight * 0.64).toFloat(), paint)
        } else if (time == -2) {
            paint.textSize = (screenHeight * 0.1).toFloat()
            canvas.drawText(context.getString(R.string.tentedenovo1), screenWidth / 2, (screenHeight * 0.2).toFloat(), paint)
            paint.textSize = (screenHeight * 0.047).toFloat()
            canvas.drawText(context.getString(R.string.tentedenovo2), screenWidth / 2, (screenHeight * 0.36).toFloat(), paint)
            canvas.drawText(context.getString(R.string.tentedenovo3), screenWidth / 2, (screenHeight * 0.44).toFloat(), paint)
            for (x in 0..7)
                canvas.drawBitmap(tile[3]!!, x * 200 * fractionScreenSize - 100 * fractionScreenSize, (screenHeight * 0.54).toFloat(), paint)
        } else if (time == -1) {
            for (y in course[stage].indices)
                for (x in course[stage][y].indices)
                    if (course[stage][y][x] != 0)
                        canvas.drawBitmap(miniTiles[course[stage][y][x]]!!, screenWidth / 2 - course[stage][y].size * miniTilesSize / 2 + x * miniTilesSize, screenHeight / 2 - course[stage].size * miniTilesSize / 2 + y * miniTilesSize, paint)
            canvas.drawBitmap(star!!, screenWidth / 2 - 75 * fractionScreenSize, (screenHeight * 0.02).toFloat(), paint)
            canvas.drawBitmap(star!!, screenWidth / 2 - 25 * fractionScreenSize, (screenHeight * 0.02).toFloat(), paint)
            canvas.drawBitmap(star!!, screenWidth / 2 + 25 * fractionScreenSize, (screenHeight * 0.02).toFloat(), paint)
            canvas.drawBitmap(btnPrevious!!, 40 * fractionScreenSize, (screenHeight - 300) / 2 * fractionScreenSize, paint)
            canvas.drawBitmap(btnNext!!, screenWidth - 240 * fractionScreenSize, (screenHeight - 300) / 2 * fractionScreenSize, paint)
            paint.textSize = ((screenWidth - 200 * fractionScreenSize) * 0.06).toFloat()
            canvas.drawText((maxSpeed[stage] * 5).toString() + " Km/h", screenWidth / 2, (screenHeight * 0.972).toFloat(), paint)
        } else if (time > 0) {
            for (y in course[stage].indices)
                for (x in course[stage][y].indices)
                    if (course[stage][y][x] != 0)
                        canvas.drawBitmap(tile[course[stage][y][x]]!!, carPositionX + x * 200 * fractionScreenSize + screenWidth / 2, carPositionY + y * 200 * fractionScreenSize + screenHeight / 2, paint)
            canvas.drawBitmap(car[angle3 / 3]!!, (screenWidth - car[angle3 / 3]!!.width) / 2, (screenHeight - car[angle3 / 3]!!.height) / 2, paint)
            if (time > 100 && stageTimeLimit[stage] - time > 90 && stageTimeLimit[stage] - time < 510 && (stageTimeLimit[stage] - time) % 100 < 10)
                canvas.drawBitmap(numbers[(stageTimeLimit[stage] - time) / 100]!!, (screenWidth - numbers[(stageTimeLimit[stage] - time) / 100]!!.height) / 2, (screenHeight - numbers[(stageTimeLimit[stage] - time) / 100]!!.height) / 2, paint)
            canvas.drawBitmap(star!!, (screenHeight * 0.04).toFloat(), (screenHeight * 0.04).toFloat(), paint)
            canvas.drawBitmap((if (!walkOut || stageTimeLimit[stage] > time) star else opaqueStar)!!, (screenHeight * 0.04).toFloat() + 50 * fractionScreenSize, (screenHeight * 0.04).toFloat(), paint)
            canvas.drawBitmap((if (!walkOut && stageTimeLimit[stage] > time) star else opaqueStar)!!, (screenHeight * 0.04).toFloat() + 100 * fractionScreenSize, (screenHeight * 0.04).toFloat(), paint)
            paint.color = Color.rgb(127, 127, 127)
            if (ccwPressed) {
                canvas.drawCircle(80 * fractionScreenSize, screenHeight - 80 * fractionScreenSize, 58 * fractionScreenSize, paint)
                canvas.drawBitmap(btnccw!!, 20 * fractionScreenSize, screenHeight - 140 * fractionScreenSize, paint)
            }
            if (cwPressed) {
                canvas.drawCircle(screenWidth - 80 * fractionScreenSize, screenHeight - 80 * fractionScreenSize, 58 * fractionScreenSize, paint)
                canvas.drawBitmap(btncw!!, screenWidth - 140 * fractionScreenSize, screenHeight - 140 * fractionScreenSize, paint)
            }
            canvas.drawRect(screenWidth - 96 * fractionScreenSize, 18 * fractionScreenSize, screenWidth - 20 * fractionScreenSize, 94 * fractionScreenSize, paint)
            canvas.drawBitmap(menu!!, screenWidth - 90 * fractionScreenSize, 24 * fractionScreenSize, paint)
        }
    }
}
