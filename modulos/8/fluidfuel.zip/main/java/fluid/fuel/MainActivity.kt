package fluid.fuel

import android.app.Activity
import android.os.Bundle

class MainActivity : Activity() {
    override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)
        setContentView(FluidFuel(this))
    }
}