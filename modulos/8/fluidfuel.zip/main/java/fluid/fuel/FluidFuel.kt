package fluid.fuel

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import java.util.Timer
import java.util.TimerTask

internal class FluidFuel(context: Context?) : View(context) {
    var apertandoDir = false
    var apertandoEsq = false
    var menuScreen = true
    var angulo = 0
    var anguloOponente = 0
    var delayColisao = 0
    var acabamentocurva = 20
    var qtdFases = 6
    var fase = 0
    var posOponenteX = 0f
    var posOponenteY = 0f
    var screenWidth = 0f
    var screenHeight = 0f
    var posicaoX = 0f
    var posicaoY = 0f
    var fractionScreenSize = 0f
    var btndir: Bitmap? = null
    var btnesq: Bitmap? = null
    var carro: Bitmap? = null
    var angulosIniciais = intArrayOf(270, 0, 90, 180, 180, 0, 270, 0)
    var fatorDeslocamentoOponenteX = intArrayOf(0, 0, 0, -9, 9)
    var fatorDeslocamentoOponenteY = intArrayOf(0, 9, -9, 0, 0)
    var velocidades = floatArrayOf(0.5f, 0.54f, 0.58f, 0.62f, 0.66f, 0.68f)
    var velocidadesOponente = floatArrayOf(0.41f, 0.48f, 0.5f, 0.54f, 0.58f, 0.61f)
    var pontos = arrayOf(".", ":", ": .", ": :", ": : .", ": : :")
    var imgOponente = arrayOfNulls<Bitmap>(4)
    var imagePista = arrayOfNulls<Bitmap>(4)
    var indicaInicio = arrayOf(
        intArrayOf(2, 0),
        intArrayOf(4, 2),
        intArrayOf(0, 10),
        intArrayOf(0, 16),
        intArrayOf(4, 12),
        intArrayOf(14, 14),
        intArrayOf(8, 0),
        intArrayOf(6, 2)
    )
    var tracados = arrayOf(
        arrayOf(
            intArrayOf(0, 0, 0, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 2),
            intArrayOf(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2),
            intArrayOf(4, 4, 2, 0, 1, 0, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 2),
            intArrayOf(0, 0, 2, 0, 1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2),
            intArrayOf(0, 0, 2, 0, 1, 0, 2, 0, 4, 4, 4, 4, 4, 4, 2, 0, 1, 0, 2),
            intArrayOf(1, 0, 2, 0, 1, 3, 3, 0, 1, 0, 0, 0, 0, 0, 2, 0, 1, 0, 2),
            intArrayOf(1, 0, 2, 0, 0, 0, 0, 0, 1, 0, 2, 3, 3, 0, 2, 0, 1, 0, 2),
            intArrayOf(1, 0, 4, 4, 4, 4, 4, 4, 1, 0, 2, 0, 1, 0, 4, 4, 1, 0, 2),
            intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1, 0, 0, 0, 0, 0, 2),
            intArrayOf(1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 1, 3, 3, 3, 3, 3, 3)
        ),
        arrayOf(
            intArrayOf(2, 3, 3, 3, 3, 3, 3, 0, 2, 3, 3, 3, 3, 0, 2, 3, 3, 3, 3, 3),
            intArrayOf(2, 0, 0, 0, 0, 0, 1, 0, 2, 0, 0, 0, 1, 0, 2, 0, 0, 0, 0, 1),
            intArrayOf(2, 0, 4, 4, 2, 0, 1, 0, 4, 4, 2, 0, 1, 3, 3, 0, 0, 0, 0, 1),
            intArrayOf(2, 0, 1, 0, 2, 0, 1, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1),
            intArrayOf(0, 0, 1, 0, 2, 0, 1, 0, 0, 0, 4, 4, 4, 4, 4, 4, 4, 2, 0, 1),
            intArrayOf(0, 0, 0, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1),
            intArrayOf(2, 3, 3, 3, 3, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1),
            intArrayOf(2, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1),
            intArrayOf(4, 4, 4, 4, 2, 0, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 1),
            intArrayOf(0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
            intArrayOf(0, 0, 0, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 1)
        ),
        arrayOf(
            intArrayOf(0, 0, 2, 3, 3, 3, 3, 3, 3, 3, 3),
            intArrayOf(0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0),
            intArrayOf(0, 0, 2, 0, 4, 4, 4, 4, 4, 4, 2),
            intArrayOf(0, 0, 2, 0, 1, 0, 0, 0, 0, 0, 2),
            intArrayOf(0, 0, 2, 0, 1, 0, 2, 3, 3, 0, 2),
            intArrayOf(0, 0, 2, 0, 1, 0, 2, 0, 1, 0, 2),
            intArrayOf(2, 3, 3, 0, 1, 0, 2, 0, 1, 0, 2),
            intArrayOf(2, 0, 0, 0, 1, 0, 2, 0, 1, 0, 2),
            intArrayOf(4, 4, 4, 4, 1, 0, 2, 0, 1, 0, 2),
            intArrayOf(0, 0, 0, 0, 0, 0, 2, 0, 1, 0, 2),
            intArrayOf(0, 3, 3, 3, 3, 3, 3, 0, 1, 0, 2),
            intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2),
            intArrayOf(4, 4, 4, 4, 4, 4, 4, 4, 1, 0, 2),
            intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2),
            intArrayOf(1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3)
        ),
        arrayOf(
            intArrayOf(2, 3, 3, 0, 2, 3, 3, 0, 2, 3, 3, 3, 3, 3, 3, 0, 2),
            intArrayOf(2, 0, 1, 0, 2, 0, 1, 0, 2, 0, 0, 0, 0, 0, 1, 0, 2),
            intArrayOf(2, 0, 1, 0, 2, 0, 1, 3, 3, 0, 4, 4, 2, 0, 1, 3, 3),
            intArrayOf(2, 0, 1, 0, 2, 0, 0, 0, 0, 0, 1, 0, 2, 0, 0, 0, 0),
            intArrayOf(2, 0, 1, 0, 4, 4, 4, 4, 4, 4, 1, 0, 4, 4, 4, 4, 2),
            intArrayOf(2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2),
            intArrayOf(0, 0, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3)
        ),
        arrayOf(
            intArrayOf(2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3),
            intArrayOf(2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
            intArrayOf(4, 4, 4, 4, 2, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 1),
            intArrayOf(0, 0, 0, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
            intArrayOf(4, 4, 0, 0, 2, 0, 1, 0, 2, 3, 3, 0, 2, 0, 4, 4, 2),
            intArrayOf(1, 0, 0, 0, 2, 0, 1, 0, 2, 0, 1, 0, 2, 0, 1, 0, 2),
            intArrayOf(1, 0, 2, 3, 3, 0, 1, 0, 2, 0, 1, 3, 3, 0, 1, 0, 2),
            intArrayOf(1, 0, 2, 0, 0, 0, 1, 0, 2, 0, 0, 0, 0, 0, 1, 0, 2),
            intArrayOf(1, 0, 4, 4, 2, 0, 1, 0, 4, 4, 4, 4, 4, 4, 1, 0, 2),
            intArrayOf(1, 0, 0, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2),
            intArrayOf(1, 3, 3, 3, 3, 0, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3)
        ),
        arrayOf(
            intArrayOf(4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 2, 0, 0, 0, 0),
            intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0),
            intArrayOf(1, 0, 2, 3, 3, 3, 3, 0, 2, 3, 3, 0, 2, 0, 0, 0, 0),
            intArrayOf(1, 0, 2, 0, 0, 0, 1, 0, 2, 0, 1, 0, 2, 0, 0, 0, 0),
            intArrayOf(1, 0, 2, 0, 4, 4, 1, 0, 2, 0, 1, 0, 2, 0, 0, 0, 0),
            intArrayOf(1, 0, 2, 0, 1, 0, 0, 0, 2, 0, 1, 0, 2, 0, 0, 0, 0),
            intArrayOf(1, 0, 2, 0, 1, 0, 2, 3, 3, 0, 1, 0, 2, 0, 0, 0, 0),
            intArrayOf(1, 0, 2, 0, 1, 0, 2, 0, 0, 0, 1, 0, 2, 0, 0, 0, 0),
            intArrayOf(1, 0, 2, 0, 1, 0, 4, 4, 2, 0, 1, 0, 4, 4, 4, 4, 2),
            intArrayOf(1, 0, 2, 0, 1, 0, 0, 0, 2, 0, 1, 0, 0, 0, 0, 0, 2),
            intArrayOf(1, 0, 2, 0, 1, 3, 3, 3, 3, 0, 1, 0, 2, 3, 3, 0, 2),
            intArrayOf(1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2, 0, 1, 0, 2),
            intArrayOf(1, 0, 4, 4, 4, 4, 4, 4, 2, 0, 1, 0, 2, 0, 1, 0, 2),
            intArrayOf(1, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1, 0, 2, 0, 1, 0, 2),
            intArrayOf(1, 3, 3, 3, 3, 3, 3, 3, 3, 0, 1, 3, 3, 0, 1, 0, 0)
        )
    )
    var gameLoop: TimerTask = object : TimerTask() {
        override fun run() {
            if (!menuScreen) {
                if (apertandoDir) angulo = (angulo - 2 + 360) % 360
                if (apertandoEsq) angulo = (angulo + 2) % 360

                //curva do oponente
                if (-posOponenteY / 200 / fractionScreenSize > 0 && -posOponenteX / 200 / fractionScreenSize > 0 && -posOponenteY / 200 / fractionScreenSize < tracados[fase].size && -posOponenteX / 200 / fractionScreenSize < tracados[fase][0].size && tracados[fase][(-posOponenteY / 200 / fractionScreenSize).toInt()][(-posOponenteX / 200 / fractionScreenSize).toInt()] != 0) {
                    if (acabamentocurva < 20) acabamentocurva++
                    else {
                        acabamentocurva = 0
                        anguloOponente = tracados[fase][(-posOponenteY / 200 / fractionScreenSize).toInt()][(-posOponenteX / 200 / fractionScreenSize).toInt()]
                    }
                }

                //identifica sobre qual quadradinho de pista o carro esta nesse frame
                val sobrePista = intArrayOf(-1, -1)
                if (-posicaoY / 200 / fractionScreenSize > 0 && -posicaoX / 200 / fractionScreenSize > 0 && -posicaoY / 200 / fractionScreenSize < tracados[fase].size && -posicaoX / 200 / fractionScreenSize < tracados[fase][0].size && tracados[fase][(-posicaoY / 200 / fractionScreenSize).toInt()][(-posicaoX / 200 / fractionScreenSize).toInt()] != 0) {
                    sobrePista[0] = (-posicaoY / 200 / fractionScreenSize).toInt()
                    sobrePista[1] = (-posicaoX / 200 / fractionScreenSize).toInt()
                }

                //grama
                if (sobrePista[0] == -1) menuScreen = true

                //colisao
                if (Math.sqrt(((posicaoX - posOponenteX) * (posicaoX - posOponenteX) + (posicaoY - posOponenteY) * (posicaoY - posOponenteY)).toDouble()) < 40 * fractionScreenSize)
                    delayColisao = 20

                if (delayColisao > 0) delayColisao-- //delay da batida
                else {
                    //atualiza posicao do carro (se ele estiver no asfalto)
                    posicaoX += (fractionScreenSize * Math.sin(Math.toRadians(angulo.toDouble())) * velocidades[fase] * 11).toFloat()
                    posicaoY += (fractionScreenSize * Math.cos(Math.toRadians(angulo.toDouble())) * velocidades[fase] * 11).toFloat()
                }

                //atualiza a posicao do oponente
                posOponenteX -= (fractionScreenSize * fatorDeslocamentoOponenteX[anguloOponente] * velocidadesOponente[fase] * 1.4).toFloat()
                posOponenteY += (fractionScreenSize * fatorDeslocamentoOponenteY[anguloOponente] * velocidadesOponente[fase] * 1.4).toFloat()
            }
            invalidate() //call onDraw
        }
    }

    override fun onTouchEvent(motionEvent: MotionEvent): Boolean {
        val x = motionEvent.x
        val y = motionEvent.y
        if (motionEvent.action == MotionEvent.ACTION_UP) {
            apertandoEsq = false
            apertandoDir = false
            if (menuScreen && y < screenHeight * .58) {
                if (x < 0.26 * screenWidth) fase = (fase - 1 + qtdFases) % qtdFases
                else if (x > screenWidth - 0.26 * screenWidth) fase = (fase + 1) % qtdFases
                else { //inicializa as variaveis para a corrida
                    delayColisao = 60
                    angulo = angulosIniciais[fase]
                    when (angulosIniciais[fase]) {
                        0 -> anguloOponente = 1
                        90 -> anguloOponente = 3
                        180 -> anguloOponente = 2
                        270 -> anguloOponente = 4
                    }

                    //posicao inicial do carro
                    posicaoX = 200 * -indicaInicio[fase][1] * fractionScreenSize - 100 * fractionScreenSize
                    posicaoY = 200 * -indicaInicio[fase][0] * fractionScreenSize - 100 * fractionScreenSize

                    //posicao inicial do oponente
                    posOponenteX = 200 * -indicaInicio[fase][1] * fractionScreenSize - 100 * fractionScreenSize
                    posOponenteY = 200 * -indicaInicio[fase][0] * fractionScreenSize - 100 * fractionScreenSize

                    //distancia entre os carros
                    if (angulo == 0) {
                        posicaoX -= 40 * fractionScreenSize
                        posOponenteX += 40 * fractionScreenSize
                    }
                    if (angulo == 180) {
                        posicaoX += 40 * fractionScreenSize
                        posOponenteX -= 40 * fractionScreenSize
                    }
                    if (angulo == 90) {
                        posicaoY += 40 * fractionScreenSize
                        posOponenteY -= 40 * fractionScreenSize
                    }
                    if (angulo == 270) {
                        posicaoY -= 40 * fractionScreenSize
                        posOponenteY += 40 * fractionScreenSize
                    }
                    menuScreen = false
                }
            }
        } else {
            //mudar a rota do carrinho
            if (x < screenWidth / 2) apertandoEsq = true //user tocou na metade esquerda da tela de gameplay
            else apertandoDir = true //user tocou na metade direita da tela de gameplay
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val paint = Paint()
        paint.color = Color.rgb(52, 52, 52)
        canvas.drawPaint(paint)
        if (menuScreen) {
            paint.color = Color.rgb(255, 255, 255)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = (0.1 * screenHeight).toFloat()
            canvas.drawText(pontos[fase], screenWidth / 2, (screenHeight / 2.32).toFloat(), paint)
            canvas.drawRect(34 * fractionScreenSize, (screenHeight / 2.6 - 16 * fractionScreenSize).toFloat(), 116 * fractionScreenSize, (screenHeight / 2.6).toFloat() + 66 * fractionScreenSize, paint)
            canvas.drawRect(screenWidth - 116 * fractionScreenSize, (screenHeight / 2.6 - 16 * fractionScreenSize).toFloat(), screenWidth - 34 * fractionScreenSize, (screenHeight / 2.6 + 66 * fractionScreenSize).toFloat(), paint)
            canvas.drawBitmap(btnesq!!, 50 * fractionScreenSize, (screenHeight / 2.6).toFloat(), paint)
            canvas.drawBitmap(btndir!!, screenWidth - 100 * fractionScreenSize, (screenHeight / 2.6).toFloat(), paint)
        } else {
            canvas.save()
            canvas.rotate(angulo.toFloat(), screenWidth / 2, screenHeight / 2)
            for (y in tracados[fase].indices)
                for (x in tracados[fase][0].indices)
                    if (tracados[fase][y][x] != 0)
                        canvas.drawBitmap(imagePista[tracados[fase][y][x] - 1]!!, screenWidth / 2 + posicaoX + 200 * x * fractionScreenSize, screenHeight / 2 + posicaoY + 200 * y * fractionScreenSize, paint)
            canvas.drawBitmap(imgOponente[anguloOponente - 1]!!, screenWidth / 2 + (-posOponenteX + posicaoX) - carro!!.width / 2, screenHeight / 2 + (-posOponenteY + posicaoY) - carro!!.height / 2, paint)
            canvas.restore()
            canvas.drawBitmap(carro!!, screenWidth / 2 - carro!!.width / 2, screenHeight / 2 - carro!!.height / 2, paint)
        }
    }

    override fun onSizeChanged(newWidth: Int, newHeight: Int, oldWidth: Int, oldHeight: Int) { //called when app start
        super.onSizeChanged(newWidth, newHeight, oldWidth, oldHeight)
        screenWidth = newWidth.toFloat()
        screenHeight = newHeight.toFloat()
        fractionScreenSize = screenWidth / 600
        val resources = resources
        carro = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.o1), (72 * fractionScreenSize).toInt(), (72 * fractionScreenSize).toInt(), true)
        imgOponente[0] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.o1), (72 * fractionScreenSize).toInt(), (72 * fractionScreenSize).toInt(), true)
        imgOponente[1] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.o2), (72 * fractionScreenSize).toInt(), (72 * fractionScreenSize).toInt(), true)
        imgOponente[2] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.o3), (72 * fractionScreenSize).toInt(), (72 * fractionScreenSize).toInt(), true)
        imgOponente[3] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.o4), (72 * fractionScreenSize).toInt(), (72 * fractionScreenSize).toInt(), true)
        imagePista[0] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.p1), (200 * fractionScreenSize).toInt(), (200 * fractionScreenSize).toInt(), true)
        imagePista[1] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.p2), (200 * fractionScreenSize).toInt(), (200 * fractionScreenSize).toInt(), true)
        imagePista[2] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.p3), (200 * fractionScreenSize).toInt(), (200 * fractionScreenSize).toInt(), true)
        imagePista[3] = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.p4), (200 * fractionScreenSize).toInt(), (200 * fractionScreenSize).toInt(), true)
        btnesq = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.btnesq), (50 * fractionScreenSize).toInt(), (50 * fractionScreenSize).toInt(), true)
        btndir = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.btndir), (50 * fractionScreenSize).toInt(), (50 * fractionScreenSize).toInt(), true)
        Timer().schedule(gameLoop, 0, 10)
    }
}